//
// Created by ing.conti on 28/09/22.
//
//Matrix m1 = Matrix(1,2); // remove and uncomment the following
//Matrix m1 = Matrix( {{1, 2}, {3,4}} );

//Matrix m1 = Matrix({{8}});

//Matrix m1 = Matrix( { {6, 1, 1}, {4, -2, 5} , {2,8,7} } ); // The output you get is -306
//Matrix m1 = Matrix( { {1, 4, 2, 1}, {-1, -1, 3,2} , {0,5,7,-4} , {2,1,-3,2} } ); // The output you get is 98
//Matrix m1 = Matrix( { {1, 1}, {2,2} , {3,3} } );// The output you get is NAN

Matrix m1 = Matrix( { {3,9,5,7,3}, {1,0,2,6,-5} , {5,-3,-2,-9,9},{10,5,-2,-3,1},{-2,0,0,4,7}} ); //you should get 26000
//Matrix m1 = Matrix( { {4,5,6,0,0}, {5,-8,7,4,3} , {0,6,5,-5,-3},{8,-6,5,0,-4},{5,-8,0,-1,-2}} );//you should get 7666
